// netlify/functions/ai-proxy.js
exports.handler = async function(event, context) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return { statusCode: 500, body: JSON.stringify({ error: 'GEMINI_API_KEY not set.' }) };
  }

  let body;
  try { body = JSON.parse(event.body); }
  catch (e) { return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON' }) }; }

  const userMessage = (body.messages || [])
    .filter(m => m.role === 'user')
    .map(m => m.content)
    .join('\n');

  if (!userMessage) {
    return { statusCode: 400, body: JSON.stringify({ error: 'No message' }) };
  }

  // Try models in order until one works
  const models = [
    'gemini-2.5-flash',
    'gemini-2.5-flash-lite-preview-06-17',
    'gemini-2.5-pro'
  ];

  for (const model of models) {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: userMessage }] }],
          generationConfig: {
            maxOutputTokens: 400,
            temperature: 1.0,
            thinkingConfig: { thinkingBudget: 0 }
          }
        })
      });

      const data = await response.json();
      console.log(`Model ${model} status:`, response.status, JSON.stringify(data).slice(0, 200));

      if (!response.ok) continue; // try next model

      const text = data.candidates?.[0]?.content?.parts?.find(p => p.text)?.text || '';
      if (!text) continue;

      return {
        statusCode: 200,
        headers: cors(),
        body: JSON.stringify({ content: [{ type: 'text', text }] })
      };
    } catch (err) {
      console.error(`Model ${model} fetch error:`, err.message);
      continue;
    }
  }

  return {
    statusCode: 503,
    headers: cors(),
    body: JSON.stringify({ error: 'All Gemini models unavailable. Check function logs for details.' })
  };
};

function cors() {
  return {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type'
  };
}
