# UDIARS — Netlify Deployment Guide

## Folder structure

```
udiars-netlify/
├── index.html                     ← Full UDIARS app
├── netlify.toml                   ← Netlify build config
└── netlify/
    └── functions/
        └── ai-proxy.js            ← Serverless proxy for Gemini AI (free)
```

---

## Step 1 — Get your free Google Gemini API key (2 minutes, no card needed)

1. Go to **https://aistudio.google.com**
2. Sign in with any Google account
3. Click **Get API key** (top left or center of screen)
4. Click **Create API key**
5. Select **Create API key in new project**
6. Copy the key — it looks like `AIzaSy...`
7. Save it somewhere safe

That's it. No billing, no credit card, no approval wait.

---

## Step 2 — Deploy to Netlify

### Drag and drop (easiest, no Git needed)

1. Go to **https://app.netlify.com** and log in
2. Click **Add new site → Deploy manually**
3. Drag the entire **`udiars-netlify`** folder onto the upload area
4. Wait ~30 seconds — you'll get a live URL like `https://random-name.netlify.app`

### Via GitHub (better for ongoing updates)

1. Push the `udiars-netlify` folder contents to a GitHub repo
2. In Netlify: **Add new site → Import from Git → GitHub**
3. Select your repo, leave all build settings blank, click **Deploy**

---

## Step 3 — Add your API key (most important step)

1. In your Netlify site dashboard, click **Site configuration** in the left menu
2. Click **Environment variables**
3. Click **Add a variable**
4. Set exactly:
   - **Key:** `GEMINI_API_KEY`
   - **Value:** paste your `AIzaSy...` key
5. Click **Save**
6. Go to **Deploys → Trigger deploy → Deploy site** to pick up the new variable

Your key is stored encrypted on Netlify's servers and never touches the HTML file.

---

## Step 4 — Test

1. Open your Netlify URL
2. Click the 💬 chat bubble (bottom right corner)
3. Type: *"What is the current flood risk?"*
4. If you get a real answer, everything is working

**If the chat says "not available"** — the most common cause is Step 3 being skipped or the site not being redeployed after adding the variable. Trigger a redeploy and try again.

---

## What's live after deploying

| Feature | Status |
|---|---|
| NWS weather and flood alerts | ✅ Live — real data |
| USGS earthquake feed | ✅ Live — real data |
| OSRM route calculation | ✅ Live — real roads |
| Photon address autocomplete | ✅ Live — real geocoding |
| Map tiles | ✅ Live |
| GPS / geolocation | ✅ Live |
| Voice navigation | ✅ Live |
| UDIARS AI Assistant | ✅ Live — powered by Gemini Flash (free) |
| Community hazard reports | ⚠️ Session only — resets on refresh |

---

## Gemini free tier limits

- 15 requests per minute
- 1 million tokens per day
- No cost, no credit card

For a school project or demo this is far more than you will ever use.
You can monitor usage at **https://aistudio.google.com** under your project.

---

## Updating the app later

**Drag and drop:** re-drag the updated folder to Netlify.
**GitHub:** push your changes, Netlify auto-deploys.

The `GEMINI_API_KEY` stays set permanently — you only add it once.
